using Nefarius.ViGEm.Client;
using Nefarius.ViGEm.Client.Targets;
using Nefarius.ViGEm.Client.Targets.Xbox360;
using System;
using System.Windows.Forms;

namespace RawMouseToXbox360
{
    public partial class MainForm : Form
    {
        private ViGEmClient client;
        private IXbox360Controller controller;

        public MainForm()
        {
            this.Load += (s, e) =>
            {
                RawInputHandler.RegisterMouseAndKeyboard(this.Handle);
                InitializeViGEm();
            };
        }

        private void InitializeViGEm()
        {
            client = new ViGEmClient();
            controller = client.CreateXbox360Controller();
            controller.Connect();

            RawInputHandler.OnMouseDelta += (dx, dy) =>
            {
                Console.WriteLine($"Mouse delta received: dx={dx}, dy={dy}");

                short stickX = (short)Math.Clamp(dx * 100, -32768, 32767);
                short stickY = (short)Math.Clamp(-dy * 100, -32768, 32767);

                controller.SetAxisValue(Xbox360Axis.RightThumbX, stickX);
                controller.SetAxisValue(Xbox360Axis.RightThumbY, stickY);
                controller.SubmitReport();
            };
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            controller?.Disconnect();
            client?.Dispose();
            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == RawInputHandler.WM_INPUT)
            {
                RawInputHandler.ProcessRawInput(m.LParam);
            }
            base.WndProc(ref m);
        }
    }
}
